import React from "react";
import TradingDashboard from "../components/trading/TradingDashboard";

export default function TradingPage() {
  return <TradingDashboard />;
}
